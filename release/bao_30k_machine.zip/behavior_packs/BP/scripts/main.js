var __create = Object.create;
var __defProp = Object.defineProperty;
var __getOwnPropDesc = Object.getOwnPropertyDescriptor;
var __getOwnPropNames = Object.getOwnPropertyNames;
var __getProtoOf = Object.getPrototypeOf;
var __hasOwnProp = Object.prototype.hasOwnProperty;
var __commonJS = (cb, mod) => function __require() {
  return mod || (0, cb[__getOwnPropNames(cb)[0]])((mod = { exports: {} }).exports, mod), mod.exports;
};
var __copyProps = (to, from, except, desc) => {
  if (from && typeof from === "object" || typeof from === "function") {
    for (let key of __getOwnPropNames(from))
      if (!__hasOwnProp.call(to, key) && key !== except)
        __defProp(to, key, { get: () => from[key], enumerable: !(desc = __getOwnPropDesc(from, key)) || desc.enumerable });
  }
  return to;
};
var __toESM = (mod, isNodeMode, target) => (target = mod != null ? __create(__getProtoOf(mod)) : {}, __copyProps(
  // If the importer is in node compatibility mode or this is not an ESM
  // file that has been converted to a CommonJS file using a Babel-
  // compatible transform (i.e. "__esModule" has not been set), then set
  // "default" to the CommonJS "module.exports" for node compatibility.
  isNodeMode || !mod || !mod.__esModule ? __defProp(target, "default", { value: mod, enumerable: true }) : target,
  mod
));

// BP/scripts/events/voidBacteria.ts
import { system as system2 } from "@minecraft/server";
var require_voidBacteria = __commonJS({
  "BP/scripts/events/voidBacteria.ts"() {
    system2.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
      blockComponentRegistry.registerCustomComponent("bao_30k_machine:void_bacteria", {
        onRandomTick: (e) => {
          if (!e.block)
            return;
          const block = e.block;
          for (const n of [
            "above",
            "below",
            "north",
            "east",
            "south",
            "west"
          ]) {
            if (Math.random() > 0.25)
              continue;
            let otherBlock;
            switch (n) {
              case "above":
                otherBlock = block.above();
                break;
              case "below":
                otherBlock = block.below();
                break;
              case "north":
                otherBlock = block.north();
                break;
              case "east":
                otherBlock = block.east();
                break;
              case "south":
                otherBlock = block.south();
                break;
              case "west":
                otherBlock = block.west();
                break;
            }
            if (!otherBlock)
              return;
            if (otherBlock.isAir || otherBlock.isLiquid)
              return;
            if (otherBlock.typeId === "bao_30k_machine:void_bacteria")
              return;
            otherBlock.setType("bao_30k_machine:void_bacteria");
          }
          if (Math.random() < 0.25) {
            block.setType("minecraft:air");
          }
        }
      });
    });
  }
});

// BP/scripts/internal/init.ts
import { system as system7, world as world4 } from "@minecraft/server";

// BP/scripts/events/spawnAllay.ts
import { world } from "@minecraft/server";

// BP/scripts/events/itemShower.ts
import { ItemStack, system } from "@minecraft/server";

// BP/scripts/events/utils.ts
function randomWithinRange(a, b) {
  return Math.random() * (b - a) + a;
}
function chooseFromArray(arr) {
  const index = Math.floor(Math.random() * arr.length);
  return arr[index];
}
function chooseFromWeightedArray(arr) {
  const totalWeight = arr.reduce((sum, [weight]) => sum + weight, 0);
  const random = Math.random() * totalWeight;
  let cumulative = 0;
  for (const [weight, value] of arr) {
    cumulative += weight;
    if (random < cumulative) {
      return value;
    }
  }
  return arr[arr.length - 1][1];
}
function distanceVector3(a, b) {
  return Math.sqrt(distanceSquaredVector3(a, b));
}
function distanceSquaredVector3(a, b) {
  return (a.x - b.x) ** 2 + (a.y - b.y) ** 2 + (a.z - b.z) ** 2;
}

// BP/scripts/events/itemShower.ts
function createItemShower(dimension, location, count, itemsArray, horizontalVelocity, verticalVelocityRange) {
  for (let i = 0; i < count; i++) {
    system.runTimeout(() => {
      const itemEntity = dimension.spawnItem(new ItemStack(
        chooseFromArray(itemsArray),
        1
      ), location);
      itemEntity.applyImpulse({
        x: randomWithinRange(-1, 1) * horizontalVelocity,
        y: randomWithinRange(verticalVelocityRange[0], verticalVelocityRange[1]),
        z: randomWithinRange(-1, 1) * horizontalVelocity
      });
    }, i);
  }
}

// BP/scripts/events/spawnAllay.ts
var lootAllay = /* @__PURE__ */ new Set();
world.afterEvents.entityDie.subscribe((event) => {
  const entity = event.deadEntity;
  const entityId = entity.id;
  if (!lootAllay.has(entityId))
    return;
  lootAllay.delete(entityId);
  spawnLootAt(entity.dimension, entity.location);
});
function spawnLootAt(dimension, location) {
  createItemShower(
    dimension,
    location,
    16,
    [
      "minecraft:diamond",
      "minecraft:emerald",
      "minecraft:gold_ingot",
      "minecraft:iron_ingot"
    ],
    0.4,
    [0.35, 0.5]
  );
}
function spawnAllay({ block, dimension }) {
  const entity = dimension.spawnEntity("minecraft:allay", block.center());
  lootAllay.add(entity.id);
}

// BP/scripts/events.ts
var import_voidBacteria = __toESM(require_voidBacteria());

// BP/scripts/events/spawnBooks.ts
function spawnBooks({ block, dimension }) {
  for (let i = 0; i < Math.floor(randomWithinRange(6, 9)); i++) {
    const entity = dimension.spawnEntity("bao_30k_machine:book", block.center());
    entity.applyKnockback(
      {
        x: randomWithinRange(-0.85, 0.85),
        z: randomWithinRange(-0.85, 0.85)
      },
      randomWithinRange(0.1, 0.4)
    );
  }
}

// BP/scripts/events/cookedFood.ts
function spawnCookedFood({ block, dimension }) {
  createItemShower(
    dimension,
    block.center(),
    16,
    [
      "minecraft:cooked_chicken",
      "minecraft:cooked_beef",
      "minecraft:cooked_mutton"
    ],
    0.15,
    [0.2, 0.3]
  );
}

// BP/scripts/events/nearbyCorruption.ts
import { system as system3 } from "@minecraft/server";
function replaceBlock(dimension, location, type) {
  let block;
  try {
    block = dimension.getBlock(location);
  } catch {
    return;
  }
  if (!block)
    return;
  if (block.isAir || block.isLiquid)
    return;
  block.setType(type);
}
var corruptions = [];
function nearbyCorruption({ block, dimension }) {
  const blockLocations = [];
  const luckyBlockLocation = block.location;
  const distance = 10;
  for (let x = -distance; x <= distance; x++) {
    for (let y = -distance; y <= distance; y++) {
      for (let z = -distance; z <= distance; z++) {
        const blockLocation = {
          x: luckyBlockLocation.x + x,
          y: luckyBlockLocation.y + y,
          z: luckyBlockLocation.z + z
        };
        const distanceSquared = distanceVector3(luckyBlockLocation, blockLocation);
        if (distanceSquared + randomWithinRange(-2, 1) > distance)
          continue;
        blockLocations.push([distanceSquared, blockLocation]);
      }
    }
  }
  blockLocations.sort((a, b) => a[0] - b[0] + randomWithinRange(0, 2));
  const onlyBlockLocations = blockLocations.map((x) => x[1]);
  corruptions.push({
    dimension,
    blockQueue: onlyBlockLocations,
    oreRarity: randomWithinRange(0.65, 0.8)
  });
  if (corruptionUpdateInterval === void 0) {
    startCorruptionUpdateInterval();
  }
}
function updateCorruption(corruption) {
  const { dimension, blockQueue, oreRarity } = corruption;
  if (blockQueue.length === 0) {
    return false;
  }
  const amountPerTick = 20;
  const toProcess = blockQueue.splice(0, amountPerTick);
  for (const location of toProcess) {
    replaceBlock(
      dimension,
      location,
      Math.random() < oreRarity ? "minecraft:stone" : chooseFromWeightedArray([
        [0.3, "minecraft:coal_ore"],
        [0.3, "minecraft:iron_ore"],
        [0.2, "minecraft:diamond_ore"],
        [0.2, "minecraft:emerald_ore"],
        [0.2, "minecraft:redstone_ore"],
        [0.3, "minecraft:lapis_ore"],
        [0.1, "minecraft:coal_block"],
        [0.1, "minecraft:iron_block"],
        [0.07, "minecraft:diamond_block"],
        [0.07, "minecraft:emerald_block"],
        [0.07, "minecraft:redstone_block"],
        [0.1, "minecraft:lapis_block"],
        [0.05, "bao_30k:lucky_block"]
      ])
    );
  }
  return blockQueue.length > 0;
}
var corruptionUpdateInterval;
function startCorruptionUpdateInterval() {
  corruptionUpdateInterval = system3.runInterval(() => {
    for (let i = corruptions.length - 1; i >= 0; i--) {
      const stillActive = updateCorruption(corruptions[i]);
      if (!stillActive) {
        corruptions.splice(i, 1);
      }
    }
    if (corruptions.length === 0) {
      system3.clearRun(corruptionUpdateInterval);
      corruptionUpdateInterval = void 0;
    }
  }, 1);
}

// BP/scripts/events/orbitalLaser.ts
import { system as system4, TicksPerSecond } from "@minecraft/server";
function orbitalLaser({ block, dimension }) {
  dimension.spawnParticle(`bao_30k_machine:explosion_pre`, block.center());
  system4.runTimeout(() => {
    let blockCenter = block.center();
    const highestBlock = dimension.getTopmostBlock({
      x: blockCenter.x,
      z: blockCenter.z
    });
    if (highestBlock) {
      blockCenter.y = highestBlock.y;
    }
    dimension.spawnParticle(`bao_30k_machine:explosion_laser`, blockCenter);
    for (let i = 0; i < 64; i++) {
      system4.runTimeout(() => {
        try {
          dimension.createExplosion(
            {
              x: blockCenter.x,
              y: blockCenter.y - i,
              z: blockCenter.z
            },
            4,
            {
              allowUnderwater: true
            }
          );
        } catch {
        }
      }, i);
    }
    ;
  }, 4 * TicksPerSecond);
}

// BP/scripts/events/redstoneItems.ts
function spawnRedstoneItems({ block, dimension }) {
  createItemShower(
    dimension,
    block.center(),
    64,
    [
      "minecraft:redstone",
      "minecraft:redstone_block",
      "minecraft:redstone_lamp",
      "minecraft:dispenser",
      "minecraft:dropper",
      "minecraft:piston",
      "minecraft:sticky_piston",
      "minecraft:repeater",
      "minecraft:comparator",
      "minecraft:slime",
      "minecraft:observer",
      "minecraft:hopper",
      "minecraft:tnt",
      "minecraft:redstone_torch",
      "minecraft:crafter"
    ],
    0.15,
    [0.2, 0.3]
  );
}

// BP/scripts/events/mobExplosion.ts
import { system as system5 } from "@minecraft/server";
function mobExplosion(spawnMobFunc, velocityHorizontalRange, velocityVerticalRange, mobCount, delayPerMob = 0) {
  for (let i = 0; i < mobCount; i++) {
    system5.runTimeout(() => {
      const entity = spawnMobFunc();
      const horizontalForce = randomWithinRange(velocityHorizontalRange[0], velocityHorizontalRange[1]);
      const direction = randomWithinRange(0, 2 * Math.PI);
      entity.applyKnockback(
        {
          x: Math.sin(direction) * horizontalForce,
          z: Math.cos(direction) * horizontalForce
        },
        randomWithinRange(velocityVerticalRange[0], velocityVerticalRange[1])
      );
    }, Math.floor(delayPerMob * i));
  }
}

// BP/scripts/events/jebSheep.ts
function jebSheepExplosion({ block, dimension }) {
  mobExplosion(
    () => {
      const sheep = dimension.spawnEntity("minecraft:sheep", block.bottomCenter());
      sheep.nameTag = "jeb_";
      return sheep;
    },
    [0.1, 0.2],
    [0.3, 0.6],
    32,
    0.5
  );
}

// BP/scripts/events/anvilRain.ts
import { system as system6 } from "@minecraft/server";
function anvilRain({ dimension, player }) {
  for (let i = 0; i < 256; i++) {
    system6.runTimeout(() => {
      if (!player.isValid)
        return;
      const playerLocation = player.location;
      if (Math.random() < 0.5) {
        const dripstoneLocation = {
          x: playerLocation.x + Math.floor(randomWithinRange(-8, 8)),
          y: playerLocation.y + 10,
          z: playerLocation.z + Math.floor(randomWithinRange(-8, 8))
        };
        try {
          dimension.setBlockType(
            dripstoneLocation,
            `minecraft:pointed_dripstone`
          );
        } catch {
        }
        system6.runTimeout(() => {
          try {
            dimension.setBlockType(
              {
                x: dripstoneLocation.x,
                y: dripstoneLocation.y + 1,
                z: dripstoneLocation.z
              },
              `minecraft:pointed_dripstone`
            );
          } catch {
          }
        }, 1);
      } else {
        try {
          dimension.setBlockType(
            {
              x: playerLocation.x + Math.floor(randomWithinRange(-8, 8)),
              y: playerLocation.y + 10,
              z: playerLocation.z + Math.floor(randomWithinRange(-8, 8))
            },
            `minecraft:anvil`
          );
        } catch {
        }
      }
    }, Math.floor(i * 0.5));
  }
}

// BP/scripts/events/singleValuableItem.ts
import { ItemStack as ItemStack2 } from "@minecraft/server";
function singleValuableItem({ dimension, block }) {
  dimension.spawnItem(new ItemStack2(chooseFromArray([
    `minecraft:nether_star`,
    `minecraft:beacon`,
    `minecraft:netherite_block`,
    `minecraft:diamond_block`
  ])), block.bottomCenter());
}

// BP/scripts/events/villager.ts
import { world as world3 } from "@minecraft/server";
function villager({ block, dimension }) {
  world3.structureManager.place(
    `bao_30k:machine/villager`,
    dimension,
    block.location
  );
}

// BP/scripts/events.ts
var events_default = {
  author: "MACHINE_BUILDER",
  events: [
    nearbyCorruption,
    spawnAllay,
    spawnBooks,
    spawnCookedFood,
    orbitalLaser,
    spawnRedstoneItems,
    jebSheepExplosion,
    anvilRain,
    singleValuableItem,
    villager
  ]
};

// BP/scripts/internal/init.ts
function rollLuckyBlock(ctx) {
  if (events_default.author == "Your username here") {
    world4.sendMessage("\xA7eWarning: please set the author field in BP/events.ts to your username");
  }
  const luckyBlockEvents = events_default.events;
  if (luckyBlockEvents.length == 0) {
    world4.sendMessage("\xA7cYou have not added any events to events.ts.");
    world4.sendMessage("\xA7cTry importing your events and run /reload to see them in the game.");
    return;
  }
  const eventIndex = Math.floor(Math.random() * luckyBlockEvents.length);
  const selectedEvent = luckyBlockEvents[eventIndex];
  if (typeof selectedEvent !== "function") {
    world4.sendMessage("\xA7cThere was an error running one of your events.");
    world4.sendMessage(`\xA7cEvent at index ${eventIndex} is ${typeof selectedEvent}. Expected: function`);
    return;
  }
  try {
    selectedEvent(ctx);
  } catch (err) {
    world4.sendMessage("\xA7cThere was an error running one of your events.");
    world4.sendMessage("\xA7cView the reason in the content log.");
    throw err;
  }
}
system7.beforeEvents.startup.subscribe(({ blockComponentRegistry }) => {
  blockComponentRegistry.registerCustomComponent("bao_30k:lucky_block", {
    onPlayerBreak: (e) => {
      if (!e.player)
        return;
      const ctx = {
        block: e.block,
        brokenBlockPermutation: e.brokenBlockPermutation,
        dimension: e.block.dimension,
        player: e.player
      };
      rollLuckyBlock(ctx);
    }
  });
});
export {
  rollLuckyBlock
};
